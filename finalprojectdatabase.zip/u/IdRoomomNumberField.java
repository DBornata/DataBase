
public class IdRoomomNumberField {

}
