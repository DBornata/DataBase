import java.net.URL;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class print {
    String dbURL = "jdbc:mysql://localhost:3306/hotelmanagment?useSSL=false&allowPublicKeyRetrieval=true";
    String username = "root"; // تعديل "your_username" لاسم المستخدم الخاص بك
    String password = "1200284";
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField roomtype;

    @FXML
    private TextField roomnum;

    @FXML
    private TextField datein;

    @FXML
    private TextField dateout;

    @FXML
    private TextField payment;

    @FXML
    private TextField idc;

    @FXML
    private Button show;

    @FXML
    void date_out(ActionEvent event) {

    }

    @FXML
    void datein(ActionEvent event) {

    }

    @FXML
    void idC(ActionEvent event) {

    }

    @FXML
    void payment(ActionEvent event) {

    }

    @FXML
    void roomid(ActionEvent event) {

    }

    @FXML
    void roomtype(ActionEvent event) {

    }
    @FXML
    void show(ActionEvent event) {
        try {
            Connection connection = (Connection) DriverManager.getConnection(dbURL, username, password);
    
            // Retrieve the customer ID from the input field
            String customerId = idc.getText();
    
            String query = "SELECT * FROM Customer c " +
               "JOIN Room_Cus rc ON c.IDC = rc.IDC " +
               "JOIN Room r ON rc.IDR = r.IDR " +
               "JOIN Payment p ON rc.IDC = p.IDC " +
               "WHERE c.IDC = ? " +  // Add a WHERE clause to filter by customer ID
               "ORDER BY rc.Date_in DESC LIMIT 1";
    
            PreparedStatement statement = (PreparedStatement) connection.prepareStatement(query);
            statement.setString(1, customerId);  // Set the customer ID parameter
            ResultSet resultSet = statement.executeQuery();
    
            if (resultSet.next()) {
                // Retrieve the column values from the result set
                String roomType = resultSet.getString("Room_type");
                String roomId = resultSet.getString("IDR");
                String dateIn = resultSet.getString("date_in");
                String dateOut = resultSet.getString("date_out");
                String Amount = resultSet.getString("Amount");
    
                // Assign the retrieved values to UI components (text fields)
                roomtype.setText(roomType);
                roomnum.setText(roomId);
                datein.setText(dateIn);
                dateout.setText(dateOut);
                payment.setText(Amount);
            } else {
                // No records found
                System.out.println("No records found");
            }
    
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    void initialize() {
        assert roomtype != null : "fx:id=\"roomtype\" was not injected: check your FXML file 'print.fxml'.";
        assert roomnum != null : "fx:id=\"roomnum\" was not injected: check your FXML file 'print.fxml'.";
        assert datein != null : "fx:id=\"datein\" was not injected: check your FXML file 'print.fxml'.";
        assert dateout != null : "fx:id=\"dateout\" was not injected: check your FXML file 'print.fxml'.";
        assert payment != null : "fx:id=\"payment\" was not injected: check your FXML file 'print.fxml'.";
        assert idc != null : "fx:id=\"idc\" was not injected: check your FXML file 'print.fxml'.";
        assert show != null : "fx:id=\"show\" was not injected: check your FXML file 'print.fxml'.";

    }
}

