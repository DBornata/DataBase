import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class SceneBuilder6  {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField roomtype;

    @FXML
    private TextField roomnum;

    @FXML
    private TextField datein;

    @FXML
    private TextField dateout;

    @FXML
    private TextField payment;

    @FXML
    private TextField idc;

    @FXML
    void add(ActionEvent event) {

    }

    @FXML
    void date_out(ActionEvent event) {

    }

    @FXML
    void datein(ActionEvent event) {

    }

    @FXML
    void idC(ActionEvent event) {

    }

    @FXML
    void payment(ActionEvent event) {

    }

    @FXML
    void roomid(ActionEvent event) {

    }

    @FXML
    void roomtype(ActionEvent event) {

    }

    @FXML
    void initialize() {
        assert roomtype != null : "fx:id=\"roomtype\" was not injected: check your FXML file '6.fxml'.";
        assert roomnum != null : "fx:id=\"roomnum\" was not injected: check your FXML file '6.fxml'.";
        assert datein != null : "fx:id=\"datein\" was not injected: check your FXML file '6.fxml'.";
        assert dateout != null : "fx:id=\"dateout\" was not injected: check your FXML file '6.fxml'.";
        assert payment != null : "fx:id=\"payment\" was not injected: check your FXML file '6.fxml'.";
        assert idc != null : "fx:id=\"idc\" was not injected: check your FXML file '6.fxml'.";

    }
}
