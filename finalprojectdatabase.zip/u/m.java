import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
public class m extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        Pane root = FXMLLoader.load(getClass().getResource("0.fxml"));
        Scene scene =new Scene(root,700,700);

        primaryStage.setScene(scene);
        primaryStage.setTitle("welecome to hotel");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}