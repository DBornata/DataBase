import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import com.mysql.jdbc.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

public class report {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hotelmanagment?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "1200284";

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    void customet(ActionEvent event) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String sql = "SELECT MONTH(Date_in) AS month, COUNT(*) AS customerCount "
                    + "FROM Room_Cus "
                    + "WHERE (Date_in >= ? AND Date_in <= ?) OR (Date_out >= ? AND Date_out <= ?) "
                    + "GROUP BY MONTH(Date_in)";
    
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "2023-01-01"); // تاريخ بداية السنة
            stmt.setString(2, "2023-12-31"); // تاريخ نهاية السنة
            stmt.setString(3, "2023-01-01"); // تاريخ بداية السنة
            stmt.setString(4, "2023-12-31"); // تاريخ نهاية السنة
    
            ResultSet rs = stmt.executeQuery();
    
            CategoryAxis xAxis = new CategoryAxis();
            NumberAxis yAxis = new NumberAxis();
            BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
            chart.setTitle("Number of Customers per Month in 2023");
    
            XYChart.Series<String, Number> series = new XYChart.Series<>();
    
            while (rs.next()) {
                int month = rs.getInt("month");
                int customerCount = rs.getInt("customerCount");
                String monthName = getMonthName(month); // تابع للحصول على اسم الشهر بناءً على الرقم
                series.getData().add(new XYChart.Data<>(monthName, customerCount));
            }
    
            chart.getData().add(series);
    
            VBox vbox = new VBox(chart);
            vbox.setSpacing(10);
            vbox.setPadding(new Insets(10));
    
            Stage stage = new Stage();
            stage.setTitle("Customer Chart");
            stage.setScene(new Scene(vbox));
            stage.show();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("An error occurred while retrieving customer data.");
        }
    }
    

    @FXML
    void profit(ActionEvent event) {

        Stage stage = new Stage();
        stage.setTitle("Select Year");

        DatePicker datePicker = new DatePicker();
        calculateProfitLossByYears();
      


    }
    private void calculateProfitLossByYears() {
        int year=2023;
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            LineChart<String, Number> chart = new LineChart<>(new CategoryAxis(), new NumberAxis());
            chart.setTitle("Profit/Loss for Year " + year);
            chart.setLegendVisible(false);
    
            XYChart.Series<String, Number> series = new XYChart.Series<>();
    
            for (int month = 1; month <= 12; month++) {
                calculateProfitLossByMonth(month, year, series);
            }
    
            chart.getData().add(series);
    
            VBox vbox = new VBox(chart);
            vbox.setSpacing(10);
            vbox.setPadding(new Insets(10));
    
            Stage stage = new Stage();
            stage.setTitle("Profit/Loss Chart");
            stage.setScene(new Scene(vbox));
            stage.show();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while calculating the profit/loss.");
        }
    }
    private String getMonthName(int month) {
        return switch (month) {
            case 1 -> "January";
            case 2 -> "February";
            case 3 -> "March";
            case 4 -> "April";
            case 5 -> "May";
            case 6 -> "June";
            case 7 -> "July";
            case 8 -> "August";
            case 9 -> "September";
            case 10 -> "October";
            case 11 -> "November";
            case 12 -> "December";
            default -> "";
        };
    }
    
    private void calculateProfitLossByMonth(int month, int year, XYChart.Series<String, Number> series) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String sql = "SELECT SUM(r.Salary) AS total_salary "
                    + "FROM Customer c "
                    + "JOIN Room_Cus rc ON c.IDC = rc.IDC "
                    + "JOIN Room r ON rc.IDR = r.IDR "
                    + "WHERE MONTH(rc.Date_in) = ? AND YEAR(rc.Date_in) = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, month);
            stmt.setInt(2, year);
            ResultSet rs = stmt.executeQuery();
    
            if (rs.next()) {
                double profitLoss = rs.getDouble("total_salary");
                String monthName = getMonthName(month);
                series.getData().add(new XYChart.Data<>(monthName, profitLoss));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while calculating the profit/loss for month " + month);
        }
    }
   
    

    @FXML
    void room(ActionEvent event) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String sql = "SELECT Available, COUNT(*) AS Count FROM Room GROUP BY Available";

            Statement stmt = (Statement) conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            int availableRooms = 0;
            int unavailableRooms = 0;

            while (rs.next()) {
                boolean available = rs.getBoolean("Available");
                int count = rs.getInt("Count");

                if (available) {
                    availableRooms = count;
                } else {
                    unavailableRooms = count;
                }
            }

            showRoomChart(availableRooms, unavailableRooms);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while retrieving room data.");
        }
    }

    @FXML
    void initialize() {

    }

  
    

    private void showProfitLossChart(double profitLoss) {
        Stage stage = new Stage();
        stage.setTitle("Profit/Loss Chart");

        // Create axes
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();

        // Create chart
        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setTitle("Profit/Loss");
        chart.setLegendVisible(false);

        // Create data series
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.getData().add(new XYChart.Data<>("Profit/Loss", profitLoss));

        // Add data series to chart
        chart.getData().add(series);

        // Create a VBox to hold the chart
        VBox vbox = new VBox(chart);
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10));

        // Show the chart
        stage.setScene(new Scene(vbox));
        stage.show();
    }
    
    private void showRoomChart(int availableRooms, int unavailableRooms) {
        Stage stage = new Stage();
        stage.setTitle("Room Availability Chart");

        // Create axes
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();

        // Create chart
        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setTitle("Room Availability");
        chart.setLegendVisible(false);

        // Create data series
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.getData().add(new XYChart.Data<>("Available", availableRooms));
        series.getData().add(new XYChart.Data<>("Unavailable", unavailableRooms));

        // Add data series to chart
        chart.getData().add(series);

        // Create a VBox to hold the chart
        VBox vbox = new VBox(chart);
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10));

        // Show the chart
        stage.setScene(new Scene(vbox));
        stage.show();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
