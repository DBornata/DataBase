import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javafx.event.ActionEvent;
import java.util.Date;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.text.Text;
public class infohotel {
    String dbURL = "jdbc:mysql://localhost:3306/hotelmanagment?useSSL=false&allowPublicKeyRetrieval=true";
    String username = "root";
    String password = "1200284";

    @FXML
    private TextField idc;

    @FXML
    private Text datein;

    @FXML
    private Text dateout;

    @FXML
    private Text time_left;

   
@FXML
void idc(ActionEvent event) {
    int customerId = Integer.parseInt(idc.getText());

    try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
        // استعلام SQL للتحقق من وجود الزبون واسترداد تفاصيل الحجز إن وجد
        String query = "SELECT DISTINCT * FROM Customer c JOIN Room_Cus rc ON c.IDC = rc.IDC JOIN Room r ON rc.IDR = r.IDR WHERE c.IDC = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, customerId);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String dateInStr = resultSet.getString("Date_in");
            String dateOutStr = resultSet.getString("Date_out");
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dateIn = dateFormat.parse(dateInStr);
            Date dateOut = dateFormat.parse(dateOutStr);

            long timeDifferenceInMillis = dateOut.getTime() - dateIn.getTime();
            double out = timeDifferenceInMillis / (1000.0 * 60 * 60 * 24);
            datein.setText( "From: " +dateInStr);
            dateout.setText("To: " +dateOutStr);
            String outText = String.format("Number of days: %.2f", out);
            time_left.setText(outText);
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("This customer ID does not exist.");
            alert.showAndWait();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    @FXML
    void initialize() {
        assert idc != null : "fx:id=\"idc\" was not injected: check your FXML file 'infohotel.fxml'.";
        assert datein != null : "fx:id=\"datein\" was not injected: check your FXML file 'infohotel.fxml'.";
        assert dateout != null : "fx:id=\"dateout\" was not injected: check your FXML file 'infohotel.fxml'.";
        assert time_left != null : "fx:id=\"time_left\" was not injected: check your FXML file 'infohotel.fxml'.";
    }
}
